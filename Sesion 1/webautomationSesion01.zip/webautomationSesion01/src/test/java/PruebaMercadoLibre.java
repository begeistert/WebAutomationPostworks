import net.bytebuddy.asm.Advice;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class PruebaMercadoLibre {

    private WebDriver driver;


    @BeforeTest
    public void beforeTest() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/WebDriver/chromedriver.exe");
        driver = new ChromeDriver();

        driver.manage().window().maximize();
        driver.get("https://mercadolibre.com.mx/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        //driver.close();
    }
   //1
    @Test
    public void test() {
    }
    //2
    @Test
    public void testVerificarUrl() {
        assertEquals(driver.getCurrentUrl(), "https://www.mercadolibre.com.mx/");
    }
    //3
    @Test
    public void testVerificartitulo() {
        assertEquals(driver.getTitle(), "Mercado Libre México - Envíos Gratis en el día");
    }
    //4
    @Test
    public void testVerificarClase() {
       driver.findElement(By.className("nav-categs-overlay"));
        try {
            WebElement element = driver.findElement(By.className("nav-categs-overlay"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }
    //5
    @Test
    public void testVerificarPorId() {
        driver.findElement(By.id("nav-header-menu-switch"));
        try {
            WebElement element = driver.findElement(By.id("nav-header-menu-switch"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }
   //6
    @Test
    public void testVerificaPais(){
        WebElement location = driver.findElement(By.xpath("//body[@data-country='MX']"));
        Assert.assertEquals(location.getAttribute("data-country"),"MX");
    }

    //7
    @Test
    public void TestVerificaLogin(){

        WebElement location = driver.findElement(By.xpath("//a[@data-link-id='login']"));
        Assert.assertEquals(location.getText(),"Ingresa");
    }


    //8
    @Test
    public void validateLoginPageTitle() {
        driver.get("https://www.mercadolibre.com.mx");
        WebElement location = driver.findElement(By.xpath("//a[@data-link-id='login']"));
        location.click();
        Assert.assertTrue(driver.getTitle().contains("Ingresa"));
     }
    //9
     @Test
     public void validabuscar() throws InterruptedException {

         WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
         search_bar.sendKeys("tennis");
         search_bar.sendKeys(Keys.RETURN);
         Thread.sleep(10000);

     }
     //10
     @Test
     public void verificalogo(){
         WebElement webElement = driver.findElement(By.xpath("/html/body/header/div/a[2]"));
         Assert.assertTrue(webElement.isDisplayed());

     }

     @Test
     public void verificacheckboxfull() throws InterruptedException {
      //  Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");

         WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
         search_bar.sendKeys("tennis");
         search_bar.sendKeys(Keys.RETURN);
         driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/button[1]")).click();
         Thread.sleep(10000);
         //Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");
         //Assert.assertFalse(str);

     }

    @Test
    public void verificacheckboxcodigopostal() throws InterruptedException {
        //  Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");

        WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
        search_bar.sendKeys("tennis");
        search_bar.sendKeys(Keys.RETURN);
        driver.findElement(By.xpath("\n" +
                "/html/body/div[3]/div/div/div[2]/div/div/div[1]")).click();
        Thread.sleep(10000);
        //Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");
        //Assert.assertFalse(str);

    }




    @AfterTest
    public void afterTest() {
       // driver.close();
    }
}
