import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

public class MercadoLibreTestPostWork {

    private WebDriver driver;


    @BeforeTest
    public void beforeTest() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/WebDriver/chromedriver.exe");
        driver = new ChromeDriver();

        driver.manage().window().maximize();
        driver.get("https://mercadolibre.com.mx/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        //driver.close();
    }
    //1
    @Test(priority = 1)
    public void test() {
    }
    //2
    @Test(priority = 2)
    public void testVerificarUrl() {
        assertEquals(driver.getCurrentUrl(), "https://www.mercadolibre.com.mx/");
    }
    //3
    @Test(priority = 3)
    public void testVerificartitulo() {
        assertEquals(driver.getTitle(), "Mercado Libre México - Envíos Gratis en el día");
    }
    //4
    @Test(priority = 4)
    public void testVerificarClase() {
        driver.findElement(By.className("nav-categs-overlay"));
        try {
            WebElement element = driver.findElement(By.className("nav-categs-overlay"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }
    //5
    @Test(priority = 5)
    public void testVerificarPorId() {
        driver.findElement(By.id("nav-header-menu-switch"));
        try {
            WebElement element = driver.findElement(By.id("nav-header-menu-switch"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }
    //6
    @Test(priority = 6)
    public void testVerificaPais(){
        WebElement location = driver.findElement(By.xpath("//body[@data-country='MX']"));
        Assert.assertEquals(location.getAttribute("data-country"),"MX");
    }

    //7
    @Test(priority = 7)
    public void TestVerificaLogin(){

        WebElement location = driver.findElement(By.xpath("//a[@data-link-id='login']"));
        Assert.assertEquals(location.getText(),"Ingresa");
    }


    //8
    @Test(priority = 8)
    public void validateLoginPageTitle() {
        driver.get("https://www.mercadolibre.com.mx");
        WebElement location = driver.findElement(By.xpath("//a[@data-link-id='login']"));
        location.click();
        Assert.assertTrue(driver.getTitle().contains("Ingresa"));
    }
    //9
    @Test(priority = 9)
    public void validabuscar() throws InterruptedException {


        WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
        search_bar.sendKeys("tennis");
        search_bar.sendKeys(Keys.RETURN);
        Thread.sleep(10000);

    }
    //10
    @Test(priority = 10)
    public void verificalogo(){
        WebElement webElement = driver.findElement(By.xpath("/html/body/header/div/a[2]"));
        Assert.assertTrue(webElement.isDisplayed());

    }

    @Test
    public void verificacheckboxfull() throws InterruptedException {
        //  Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");

        WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
        search_bar.sendKeys("tennis");
        search_bar.sendKeys(Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/button[1]")).click();
        Thread.sleep(10000);
        //Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");
        //Assert.assertFalse(str);

    }

    @Test
    public void verificacheckboxcodigopostal() throws InterruptedException {
        //  Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");

        WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
        search_bar.sendKeys("tennis");
        search_bar.sendKeys(Keys.RETURN);
        driver.findElement(By.xpath("\n" +
                "/html/body/div[3]/div/div/div[2]/div/div/div[1]")).click();
        Thread.sleep(10000);
        //Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");
        //Assert.assertFalse(str);

    }

    @Test
    public void pruebaTiempo() {
        driver.get("https://www.bedu.org");
        WebElement wait =
                new WebDriverWait(driver, Duration.ofSeconds(10)).until(
                        ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//*[@id=\"__next\"]/main/section[2]/div/div/div[2]/a/button"))));
        WebElement button = driver.findElement(By.xpath("//*[@id=\"__next\"]/main/section[2]/div/div/div[2]/a/button"));
        button.click();
    }
    @Test
    public void localWeb(){
        driver.get("file:///C:/Users/nomarlo/Desktop/ServicioRMI/web-automation/index.html");
        //        WebElement modal = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.tagName("p")));
        WebElement modal = new WebDriverWait(driver, Duration.ofSeconds(10)).until(driver -> driver.findElement(By.tagName("p")));
        Alert alert = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();

        //        driver.findElement(By.tagName("p"));
    }




    @AfterTest
    public void afterTest() {
         driver.close();
    }
}
