import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;




public class PruebaMercadoLibreJunit {
    private WebDriver driver;


    @BeforeEach
    public void beforeTest() {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/WebDriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://mercadolibre.com.mx/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        //driver.close();
    }

    @Test
    public void test() {

    }

    /*@Test
    public void testVerificarUrl() {
       assertEquals( "https://www.mercadolibre.com.mx/",driver.getCurrentUrl());

    }*/

    /*@Test
    public void testVerificartitulo() {
        assertEquals(driver.getTitle(), "Mercado Libre México - Envíos Gratis en el día");
    }*/

   /* @Test
    public void testVerificarClase() {
        driver.findElement(By.className("nav-categs-overlay"));
        try {
            WebElement element = driver.findElement(By.className("nav-categs-overlay"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }*/

    /*@Test
    public void testVerificarPorId() {
        driver.findElement(By.id("nav-header-menu-switch"));
        try {
            WebElement element = driver.findElement(By.id("nav-header-menu-switch"));
        }catch(Exception e) {
            assertTrue(false, "no encontrado");
        }

    }*/


    @AfterEach
    public void afterTest() {
        driver.close();
    }
}
