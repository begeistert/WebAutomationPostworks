import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class Session01 {

   @Test
   public void myFirstSeleniumTest() throws InterruptedException {
       System.setProperty("webdriver.chrome.driver", "src/test/resources/WebDriver/chromedriver.exe");
       WebDriver driver = new ChromeDriver();
       driver.manage().window().maximize();
       driver.get("https://bedu.org/");
       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
       //Thread.sleep(10000);
       driver.close();

   }


}
