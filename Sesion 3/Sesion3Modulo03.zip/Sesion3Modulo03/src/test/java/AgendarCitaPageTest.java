import org.openqa.selenium.WebDriver;

import static org.junit.jupiter.api.Assertions.*;

class AgendarCitaPageTest {

    WebDriver driver;

}