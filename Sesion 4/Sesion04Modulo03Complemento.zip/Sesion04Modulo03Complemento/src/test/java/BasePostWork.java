import org.testng.annotations.DataProvider;

public class BasePostWork {
    @DataProvider(name = "nombre_dataprovider")
    public static Object[][] metodoDataProvider(){
        return new Object[][] {
                {"Venezuela"},
                {"Caracas"},
                {"Argentina"},
                {"Buenos Aires"},
                {"Colombia"},
                {"Bogotá"},
                {"Ecuador"},
                {"Quito"}

        };
    }
}
