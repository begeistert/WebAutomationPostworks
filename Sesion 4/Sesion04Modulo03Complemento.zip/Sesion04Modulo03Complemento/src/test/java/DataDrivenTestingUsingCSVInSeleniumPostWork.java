import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;

public class DataDrivenTestingUsingCSVInSeleniumPostWorkSesion04 {

    //Indicar la ubicación del archivo csv
    String CSV_PATH = "mercado.csv";
    //Declaración de la variable de la clase CSVReader
    private CSVReader csvReader;
    //Declaración de una variable para leer los datos del csv
    String[] csvCell;


    @Test
    public void dataRead_CSV() throws IOException, CsvValidationException {
        //Creación del objeto de tipo CSVReader
        csvReader = new CSVReader(new FileReader(CSV_PATH));

        //uso de un loop para la lectura de todos los datos del csv
        while ((csvCell = csvReader.readNext()) != null) {

            // se guardan en variables las posiciones del archivo csv
            String pais = csvCell[0];
            String capital = csvCell[1];
            System.out.println("El pais es : " + pais + " y su capital es :" + capital);

        }
    }

}
