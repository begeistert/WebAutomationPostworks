import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.HomePageML;
import pages.LLenarformularioML;
import pages.agendarCitaPage;

public class DataDrivenTestingUsingDataBaseultimoPostworksesion05 {
    private WebDriver driver;
    private HomePageML homePage;
    private LLenarformularioML lLenarformularioML;
    //private pages.agendarCitaPage agendarCitaPage;

    @BeforeMethod
    public void beforeTest() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.mercadolibre.com.mx/");
    }

    @Test(dataProvider = "MySQL_dataproviderml", dataProviderClass = data_provider_ml.class)
    public void ContinuarRegistro(String name, String lastname, String email, String clave) throws InterruptedException {

        homePage = new HomePageML(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePage.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        lLenarformularioML = new LLenarformularioML(driver);
        lLenarformularioML.fillName(name);
       lLenarformularioML.fillLastname(lastname);
       lLenarformularioML.fillEmail(email);
       lLenarformularioML.fillClave(clave);
       Thread.sleep(5000);
//        if (agendarCitaPage.btn_CancelIsDispayed()) {
//
//            agendarCitaPage.fillName(name);
//            agendarCitaPage.fillLastname(lastname);
//            agendarCitaPage.fillPhone(phone);
//            // agendarCitaPage.fillEmail(email);
//            agendarCitaPage.fillCompany(company);
//            agendarCitaPage.fillJobTitle(jobtitle);
//            agendarCitaPage.fillSector(sector);
//            agendarCitaPage.fillCompanySize(company_size);
//            agendarCitaPage.fillProgram(program);
//            Thread.sleep(2000);
//        }

    }

    @AfterMethod
    public void afterTest() {
        driver.close();
    }
}
