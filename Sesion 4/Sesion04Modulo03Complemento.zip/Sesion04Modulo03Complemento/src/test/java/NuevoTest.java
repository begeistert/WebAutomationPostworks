import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NuevoTest {

    private WebDriver driver;

    @BeforeTest
    public void beforeTest() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://bedu.org/");
        Thread.sleep(2000);
    }

    @Test
    public void test() {
        By element = By.xpath("//div[@id='headlessui-tabs-panel-5']/div/div[2]/h3");
        System.out.println("Resultado metodo getText(): " + driver.findElement(element).getText());
    }

    @Test
    public void test2() {
        By element = By.xpath("//div[@id='headlessui-tabs-panel-5']/div/div[2]/h3");
        System.out.println("Resultado metodo getAttribute(): " + driver.findElement(element).getAttribute("class"));
    }

    @Test
    public void test3() {
        By element = By.xpath("//div[@id='headlessui-tabs-panel-5']/div/div[2]/h3");
        System.out.println("Resultado metodo getDomAttribute(): " + driver.findElement(element).getDomAttribute("class"));
    }

    @Test
    public void test4() {
        By element = By.xpath("//div[@id='headlessui-tabs-panel-5']/div/div[2]/h3");
        System.out.println("Resultado metodo getDomProperty(): " + driver.findElement(element).getDomProperty("class"));
    }


    @AfterTest
    public void afterTest() {
        driver.close();
    }
}
