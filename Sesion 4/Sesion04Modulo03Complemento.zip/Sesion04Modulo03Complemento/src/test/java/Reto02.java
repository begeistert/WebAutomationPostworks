import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import pages.HomePage;
import pages.agendarCitaPage;

public class Reto02 {
    private WebDriver driver;
    private HomePage homePage;
    private pages.agendarCitaPage agendarCitaPage;

    @BeforeMethod
    public void beforeTest() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://bedu.org/");
    }


    @Test(dataProviderClass = data_provider_database.class,dataProvider = "dataprovider")
    public void agendarAsesoria(String name, String lastname, String phone, String email, String company,
                                String jobtitle, String sector, String company_size, String program) throws InterruptedException {

        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePage.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        agendarCitaPage = new agendarCitaPage(driver);

        if (agendarCitaPage.btn_CancelIsDispayed()) {

            agendarCitaPage.fillName(name);
            agendarCitaPage.fillLastname(lastname);
            agendarCitaPage.fillPhone(phone);
            // agendarCitaPage.fillEmail(email);
            agendarCitaPage.fillCompany(company);
            agendarCitaPage.fillJobTitle(jobtitle);
            agendarCitaPage.fillSector(sector);
            agendarCitaPage.fillCompanySize(company_size);
            agendarCitaPage.fillProgram(program);
            Thread.sleep(2000);
        }

    }

    @AfterMethod
    public void afterTest() {
        driver.close();
    }




}

 class data_provider{

    @DataProvider(name = "dataprovider")
    public static Object[][] metodoDataProvider() {
        return new Object[][] {
                { "Juan", "Gomez", "11111111", "Juan.Gomez@gmail.com", "bedu", "QA", "Internet", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "David", "Diaz", "22222222", "David.Diaz@gmail.com", "bedu", "DEV", "Seguros", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "Jesus", "Mora", "33333333", "Jesus.Mora@gmail.com", "bedu", "QA", "Educación", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "Maria", "Fernandez", "44444444", ",Maria.Fernandez@gmail.com", "bedu", "QA", "Servicios Financieros",
                        "1 a 50 empleados", "Web Automation Testing" },
                { "Veronica", "Salas", "55555555", "Veronica.Salas@gmail.com", "bedu", "QA", "Consultoría",
                        "1 a 50 empleados", "Web Automation Testing" } };
    }
}