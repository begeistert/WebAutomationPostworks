package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePageML {
    protected WebDriver driver;

    // Definimos objetos de tipo locator y le asignamos la localización By.
    private By bnt_crea_tu_cuenta = By.xpath("//a[@data-link-id='registration']");

    // Creamos el método que recibirá el driver en esta clase
    public HomePageML(WebDriver driver){
        this.driver = driver;

        // Recuerdas la clase anterior de manejo de errores? bueno en este código hacemos una validación para asegurarnos que estemos en la homePage, validando que el título de la página sea la de bedu, si no lo es, se lanza una excepción y se devuelve la url de la página actual.
        if (!driver.getCurrentUrl().equals("https://www.mercadolibre.com.mx/")) {
            throw new IllegalStateException("Error, no se recibió la página Home de ML, la página recibida es: " + driver.getCurrentUrl());
        }

    }

    //Creamos el método validara si el botón esta disponible
    public boolean isButtonDisplayed() {
        System.out.println("isButtonDisplayed Crea tu cuenta : " + driver.findElement(bnt_crea_tu_cuenta).isDisplayed());
        return driver.findElement(bnt_crea_tu_cuenta).isDisplayed();
    }

    //Creamos el método que realizara click en el botón
    public void clickButton() throws InterruptedException {
        driver.findElement(bnt_crea_tu_cuenta).click();
        Thread.sleep(1000);
    }
}
