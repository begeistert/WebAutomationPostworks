import java.io.FileReader;
import java.io.IOException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import pages.HomePage;
import pages.agendarCitaPage;

public class DataDrivenTestingUsingCSVInSelenium {
    private WebDriver driver;
    private HomePage homePage;
    private pages.agendarCitaPage agendarCitaPage;

    // Indicar la ubicación del archivo csv
    String CSV_PATH = "test.csv";
    // Declaración de la variable de la clase CSVReader
    private CSVReader csvReader;
    // Declaración de una variable para leer los datos del csv
    String[] csvCell;

    @BeforeTest
    public void beforeTest() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://bedu.org/");
    }

    @Test
    public void agendarAsesoria() throws IOException, CsvValidationException, InterruptedException {


        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            homePage.clickButton();
        }


        agendarCitaPage = new agendarCitaPage(driver);


        if (agendarCitaPage.btn_CancelIsDispayed()) {
            // Creación del objeto de tipo CSVReader
            csvReader = new CSVReader(new FileReader(CSV_PATH));

            // uso de un loop para la lectura de todos los datos del csv
            while ((csvCell = csvReader.readNext()) != null) {

                // Se llama a los metodos de agendarCitaPage para llenar los campos del
                // formulario con la información del csv
                agendarCitaPage.fillName(csvCell[0]);
                agendarCitaPage.fillLastname(csvCell[1]);
                agendarCitaPage.fillPhone(csvCell[2]);
                //agendarCitaPage.fillEmail(csvCell[3]);
                agendarCitaPage.fillCompany(csvCell[4]);
                agendarCitaPage.fillJobTitle(csvCell[5]);
                agendarCitaPage.fillSector(csvCell[6]);
                agendarCitaPage.fillCompanySize(csvCell[7]);
                agendarCitaPage.fillProgram(csvCell[8]);
                Thread.sleep(2000);
            }

        }

    }

    @AfterTest
    public void afterTest() {
        driver.close();
    }
}
