import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import pages.HomePage;
import pages.agendarCitaPage;

public class DataDrivenTestingUsingParameters {

    private WebDriver driver;
    private HomePage homePage;
    private pages.agendarCitaPage agendarCitaPage;


    @BeforeSuite
    @Parameters({"funcionalidad"})
    public void beforeSuite(String funcionalidad) {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("-------- INICIO DE LA EJECUCIÓN DE LA FUNCIONALIDAD "+funcionalidad+" -----------");
        System.out.println("---------------------------------------------------------------------------------");
    }

    @BeforeTest
    public void beforeTest() throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://bedu.org/");
    }

    @Test
    @Parameters({"name","lastname","phone","email","company","jobtitle","sector","company_size","program"})

    public void agendarAsesoria(String name, String lastname, String phone, String email, String company,String jobtitle, String sector, String company_size, String program) throws InterruptedException{


        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            homePage.clickButton();
        }

        agendarCitaPage = new agendarCitaPage(driver);

        if (agendarCitaPage.btn_CancelIsDispayed()) {

            agendarCitaPage.fillName(name);
            agendarCitaPage.fillLastname(lastname);
            agendarCitaPage.fillPhone(phone);
            //pages.agendarCitaPage.fillEmail(email);
            agendarCitaPage.fillCompany(company);
            agendarCitaPage.fillJobTitle(jobtitle);
            agendarCitaPage.fillSector(sector);
            agendarCitaPage.fillCompanySize(company_size);
            agendarCitaPage.fillProgram(program);
            Thread.sleep(2000);
        }

    }

    @AfterTest
    public void afterTest() {
        driver.close();
    }

    @AfterSuite
    public void afterSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("--------------------     FIN DE LA EJECUCIÓN     --------------------------------");
        System.out.println("---------------------------------------------------------------------------------");
    }
}
