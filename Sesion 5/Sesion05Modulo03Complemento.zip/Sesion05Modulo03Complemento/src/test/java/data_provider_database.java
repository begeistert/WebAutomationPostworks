import java.sql.ResultSet;

import org.testng.annotations.DataProvider;

public class data_provider_database {
    @DataProvider(name = "dataprovider")
    public Object[][] metodoDataProvider() {
        return new Object[][] {
                { "Juan", "Gomez", "11111111", "Juan.Gomez@gmail.com", "bedu", "QA", "Internet", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "David", "Diaz", "22222222", "David.Diaz@gmail.com", "bedu", "DEV", "Seguros", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "Jesus", "Mora", "33333333", "Jesus.Mora@gmail.com", "bedu", "QA", "Educación", "1 a 50 empleados",
                        "Web Automation Testing" },
                { "Maria", "Fernandez", "44444444", ",Maria.Fernandez@gmail.com", "bedu", "QA", "Servicios Financieros",
                        "1 a 50 empleados", "Web Automation Testing" },
                { "Veronica", "Salas", "55555555", "Veronica.Salas@gmail.com", "bedu", "QA", "Consultoría",
                        "1 a 50 empleados", "Web Automation Testing" } };
    }

    @DataProvider(name = "MySQL_dataprovider")
    public Object[][] mySQL_Data() {

        int rowCount = 0;
        int columnCount = 0;
        String myData[][] = null;
        connection_database conect = new connection_database();
        ResultSet res;

        try {
            conect.Conector();

            // Ejecutar consulta (query) a la BD
            String query = "SELECT * FROM Agendar_Cita";
            res = conect.executeQuery(query);

            // Obtener nro de filas y columnas
            columnCount = conect.getColumnNumber(res);
            rowCount = conect.getRowsNumber(res);

            System.out.println("Columnas : " + columnCount);
            System.out.println("Filas : " + rowCount);

            // Inicializar la matriz
            myData = new String[rowCount][columnCount];
            res = conect.executeQuery(query);

            // Llenar la matriz con el resultado de la consulta MySQL
            for(int row=0; row<rowCount; row++)
            {
                res.next();

                for(int col=1; col<=columnCount; col++)
                    myData[row][col-1] = res.getString(col);
            }

            //Cerrar la conexión
            conect.closeConnexion();

        }

        catch (Exception e) {
            e.printStackTrace();
        }

        return myData;

    }

}
