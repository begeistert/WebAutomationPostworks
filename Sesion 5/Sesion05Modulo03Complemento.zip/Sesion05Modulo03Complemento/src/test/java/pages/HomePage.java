package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    protected WebDriver driver;

    // Definimos objetos de tipo locator y le asignamos la localización By.
    private By bnt_asesoria = By.xpath("//button[contains(.,'Consulta gratuita')]");


    // Creamos el método que recibirá el driver en esta clase
    public HomePage(WebDriver driver){
        this.driver = driver;

        // Recuerdas la clase anterior de manejo de errores? bueno en este código hacemos una validación para asegurarnos que estemos en la homePage, validando que el título de la página sea la de bedu, si no lo es, se lanza una excepción y se devuelve la url de la página actual.
        if (!driver.getCurrentUrl().equals("https://bedu.org/")) {
            throw new IllegalStateException("Error, no se recibió la página Home de Bedu, la página recibida es: " + driver.getCurrentUrl());
        }

    }

    //Creamos el método validara si el botón esta disponible
    public boolean isButtonDisplayed() {
        System.out.println("isButtonDisplayed Agendar Asesoria : " + driver.findElement(bnt_asesoria).isDisplayed());
        return driver.findElement(bnt_asesoria).isDisplayed();
    }

    //Creamos el método que realizara click en el botón
    public void clickButton() throws InterruptedException {
        driver.findElement(bnt_asesoria).click();
        Thread.sleep(1000);
    }
}
