import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowserTestingScript {

    private WebDriver driver;
    private HomePage homePage;
    private agendarCitaPage agendarCitaPage;

    @BeforeSuite
    public void beforeSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("-------- INICIO DE LA EJECUCIÓN DE PRUEBAS CON MULTIPLES NAVEGADORES ------------");
        System.out.println("---------------------------------------------------------------------------------");
    }

    @BeforeTest
    @Parameters({ "browser", "driver_name", "driver_path" })
    public void beforeTest(String browser, String driver_name, String driver_path) throws Exception{

        System.setProperty(driver_name, driver_path);

        if (browser.equalsIgnoreCase("Firefox")) {
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("Chrome")) {
            driver = new ChromeDriver();
        }

        else if (browser.equalsIgnoreCase("Edge")) {
            driver = new EdgeDriver();
        }else {
            //lanzamos una exepción
            throw new Exception("Navegador no parametrizado...");
        }
    }


    @BeforeMethod
    public void beforeTest() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get("https://bedu.org/");
    }

    @Test(dataProvider = "MySQL_dataprovider", dataProviderClass = data_provider.class)
    public void agendarAsesoria(String name, String lastname, String phone, String email, String company,
                                String jobtitle, String sector, String company_size, String program) throws InterruptedException {

        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePage.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        agendarCitaPage = new agendarCitaPage(driver);

        if (agendarCitaPage.btn_CancelIsDispayed()) {

            agendarCitaPage.fillName(name);
            agendarCitaPage.fillLastname(lastname);
            agendarCitaPage.fillPhone(phone);
            // agendarCitaPage.fillEmail(email);
            agendarCitaPage.fillCompany(company);
            agendarCitaPage.fillJobTitle(jobtitle);
            agendarCitaPage.fillSector(sector);
            agendarCitaPage.fillCompanySize(company_size);
            agendarCitaPage.fillProgram(program);
            Thread.sleep(2000);
        }

    }


    @AfterTest
    public void afterTest() {
        if (driver != null) {
            driver.quit();
        }
    }


    @AfterSuite
    public void afterSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("---------------     FIN DE LA EJECUCIÓN DE LA SUITE     -------------------------");
        System.out.println("---------------------------------------------------------------------------------");
    }
}
