import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;

public class SeleniumGrid2 {
    WebDriver driver;
    String baseURL, nodeURL;

    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        baseURL = "https://www.google.com/";
        nodeURL = "http://localhost:4444/";

        System.setProperty("webdriver.gecko.driver", "src/test/resources/webdriver/geckodriver.exe");
        DesiredCapabilities capability = new DesiredCapabilities();
        capability.setBrowserName("firefox");
        capability.setPlatform(Platform.ANY);
        driver = new RemoteWebDriver(new URL(nodeURL), capability);

    }

    @Test
    public void test() {
        driver.get(baseURL);
        assertEquals(driver.getCurrentUrl(),"https://www.google.com/");
    }

    @AfterTest
    public void afterTest() {
        driver.close();
    }
}
