import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;

import java.net.MalformedURLException;
import java.net.URL;
public class SeleniumGridEjemplo04chrome {


    // Creamos los objetos
    private WebDriver driver;
    private HomePage homePage;
    private agendarCitaPage agendarCitaPage;

    //Declaramos los string para guardar las url de la web y el servidor donde ejecutaremos las pruebas
    String baseURL = "https://bedu.org/";
    //String nodeURL = "http://localhost:4444/";
    String nodeURL = "http://192.168.0.6:4444/";

    @BeforeSuite
    public void beforeSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("-------   INICIO DE LA EJECUCIÓN DE PRUEBAS CON FIREFOX DE FORMA REMOTA ---------");
        System.out.println("---------------------------------------------------------------------------------");
    }



    @BeforeTest
    public void beforeTest() throws MalformedURLException{

        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        DesiredCapabilities capability = new DesiredCapabilities();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        capability.setBrowserName("chrome");
        capability.setPlatform(Platform.WIN10);
        driver = new RemoteWebDriver(new URL(nodeURL), capability);


    }

    @BeforeMethod
    public void beforeMethod() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get(baseURL);
    }


    @Test(dataProvider = "MySQL_dataprovider", dataProviderClass = data_provider.class)
    public void agendarAsesoria(String name, String lastname, String phone, String email, String company,
                                String jobtitle, String sector, String company_size, String program) throws InterruptedException {

        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePage.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        agendarCitaPage = new agendarCitaPage(driver);

        if (agendarCitaPage.btn_CancelIsDispayed()) {

            agendarCitaPage.fillName(name);
            agendarCitaPage.fillLastname(lastname);
            agendarCitaPage.fillPhone(phone);
            // agendarCitaPage.fillEmail(email);
            agendarCitaPage.fillCompany(company);
            agendarCitaPage.fillJobTitle(jobtitle);
            agendarCitaPage.fillSector(sector);
            agendarCitaPage.fillCompanySize(company_size);
            agendarCitaPage.fillProgram(program);
            Thread.sleep(2000);
        }

    }


    @AfterTest
    public void afterTest() {

        //si el driver existe lo cierra
        if (driver != null) {
            driver.quit();
        }
    }


    @AfterSuite
    public void afterSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("---------------     FIN DE LA EJECUCIÓN DE LA SUITE     -------------------------");
        System.out.println("---------------------------------------------------------------------------------");
    }
}
