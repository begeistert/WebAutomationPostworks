import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.*;

import java.net.MalformedURLException;
import java.net.URL;

public class SeleniumGridPostWorkMl {

    // Creamos los objetos
    private WebDriver driver;
    private HomePageML homePageML;
    private LLenarformularioML lLenarformularioML;

    //Declaramos los string para guardar las url de la web y el servidor donde ejecutaremos las pruebas
    String baseURL = "https://mercadolibre.com.mx/";
    //String nodeURL = "http://localhost:4444/";
    String nodeURL = "http://192.168.0.6:4444/";

    @BeforeSuite
    public void beforeSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("-------   INICIO DE LA EJECUCIÓN DE PRUEBAS CON FIREFOX DE FORMA REMOTA POSTWORK---------");
        System.out.println("---------------------------------------------------------------------------------");
    }



    @BeforeTest
    public void beforeTest() throws MalformedURLException {

        System.setProperty("webdriver.chrome.driver", "src/test/resources/webdriver/chromedriver.exe");
        DesiredCapabilities capability = new DesiredCapabilities();
        capability.setBrowserName("chrome");
        capability.setPlatform(Platform.WIN10);
        driver = new RemoteWebDriver(new URL(nodeURL), capability);

    }

    @BeforeMethod
    public void beforeMethod() throws InterruptedException {
        driver.manage().window().maximize();
        driver.get(baseURL);
    }

    @Test(dataProvider = "MySQL_dataproviderml", dataProviderClass = data_providers.class)
    public void ContinuarRegistro(String name, String lastname, String email, String clave) throws InterruptedException
    {

        homePageML = new HomePageML(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePageML.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePageML.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        lLenarformularioML = new LLenarformularioML(driver);
        lLenarformularioML.fillName(name);
        lLenarformularioML.fillLastname(lastname);
        lLenarformularioML.fillEmail(email);
        lLenarformularioML.fillClave(clave);
        Thread.sleep(5000);

    }

    @AfterTest
    public void afterTest() {

        //si el driver existe lo cierra
        if (driver != null) {
            driver.quit();
        }
    }


    @AfterSuite
    public void afterSuite() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("---------------     FIN DE LA EJECUCIÓN DE LA SUITE     -------------------------");
        System.out.println("---------------------------------------------------------------------------------");
    }
}
