import org.testng.annotations.DataProvider;

public class data_provider {

    @DataProvider(name = "dataprovider_calc")
    public Object[][] metodoDataProviderCalc() {
        return new Object[][] {
                {20,9},
                {100,1},
                {100,92} };
    }

}
