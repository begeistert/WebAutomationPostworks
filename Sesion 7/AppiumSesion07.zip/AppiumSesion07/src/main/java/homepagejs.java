import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class homepagejs {
        protected WebDriver driver;
        protected Actions actions;
        protected JavascriptExecutor jse;
        private By consultingButtonSelector= By.xpath("//button[contains(.,'Consulta gratuita')]");
        public homepagejs(WebDriver driver) {
            this.driver = driver;
            actions = new Actions(driver);
            jse = (JavascriptExecutor)driver;
            if(!driver.getCurrentUrl().equals("https://bedu.org/")) {
                throw new IllegalStateException("You are not in the homepage");
            }
        }
        public agendarCitaPage  scheduleConstulting(){
            WebElement consultingButton = driver.findElement(consultingButtonSelector);
//        actions.moveToElement(consultingButton).click().perform();
            jse.executeAsyncScript("arguments[0].click();", consultingButton);
//        consultingButton.click();
//        return new ScheduleDatePage(driver);
            return new agendarCitaPage(driver);
        }
//    public String getConsultingButtonText(){
//
//    }
    }

