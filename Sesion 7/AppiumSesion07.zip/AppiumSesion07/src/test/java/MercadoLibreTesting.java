import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class MercadoLibreTesting {

    AndroidDriver driver;
    MercadoLibrePage mercadoLibrePage;
    DesiredCapabilities dc = new DesiredCapabilities();

    @BeforeTest
    public void beforeTest() throws MalformedURLException {

        //Configuramos los DesiredCapabilities
        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 3a API 30p");
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        dc.setCapability("appium:appPackage", "com.mercadolibre");
        //dc.setCapability("appium:appActivity", "com.mercadolibre.mercadopago.GoogleStoreInterceptorActivity");
        //dc.setCapability("appium:appActivity", "com.mercadolibre.activities.SplashActivity");
        //dc.setCapability("appium:appActivity", "com.mercadolibre.android.dynamic.core.DynamicActivity");
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.settings.SettingsActivity");


        //Establecemos la conexion con el server de Appium
        driver = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), dc);
        System.out.println("Application started");

        //
        mercadoLibrePage = new MercadoLibrePage(driver);


    }

    @Test
    public void ingresarAjustes() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.settings.SettingsActivity");
        Thread.sleep(5000);
    }

    @Test
    public void ingresarSplash() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.SplashActivity");
        Thread.sleep(5000);
    }

    @Test
    public void ingresarInterceptor() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.mercadopago.GoogleStoreInterceptorActivity");
        Thread.sleep(5000);
    }

    @Test
    public void ingresarDynamic() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.android.dynamic.core.DynamicActivity");
        Thread.sleep(5000);
    }
    @Test
    public void ingresarDomicilio() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.android.dynamic.core.DynamicActivitycom.mercadolibre.activities.myaccount.addresses.MyAccountAddUserAddressActivity - Domicilio");
        Thread.sleep(5000);
    }
    @Test
    public void ingresarAcercaDe() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.settings.AboutActivity - Acerca de Mercado Libre");
        Thread.sleep(5000);
    }
    @Test
    public void ingresarMisDatos() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.myaccount.RegisterActivity - Mis datos");
        Thread.sleep(5000);
    }
    @Test
    public void ingresarPopUp(){
        dc.setCapability("appium:appActivity", "com.mercadolibre.activities.notifications.AskPopupActivity - ");
    }

    @Test
    public void ingresarSeguridad() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.android.security_options.security_options.ui.SiteSecurityWebViewActivity - Seguridad");
        Thread.sleep(5000);
    }

    @Test
    public void ingresarSearchInput() throws InterruptedException {
        dc.setCapability("appium:appActivity", "com.mercadolibre.android.search.input.activities.SearchInputActivity - Mercado Libre");
        Thread.sleep(5000);
    }

    @AfterTest
    public void afterTest() {
        driver.quit();
    }
}
