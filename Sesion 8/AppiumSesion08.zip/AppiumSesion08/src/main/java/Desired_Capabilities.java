
import java.net.MalformedURLException;
import java.net.URL;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
public class Desired_Capabilities {
    //Inicializamos el AndroidDriver
    AndroidDriver driver;

    @BeforeTest
    public void beforeTest() throws MalformedURLException {

        //Configuramos los DesiredCapabilities

        DesiredCapabilities dc = new DesiredCapabilities();

        // DesiredCapabilities Generales
        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 3a API 30p");
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        dc.setCapability(MobileCapabilityType.LANGUAGE, "en");
        dc.setCapability(MobileCapabilityType.LOCALE, "US");
        dc.setCapability(MobileCapabilityType.ORIENTATION, "PORTRAIT");
        dc.setCapability(MobileCapabilityType.NO_RESET, "true");
        dc.setCapability(MobileCapabilityType.FULL_RESET, "false");


        // DesiredCapabilities ANDROID
        dc.setCapability("appium:appPackage", "com.google.android.calculator");
        dc.setCapability("appium:appActivity", "com.android.calculator2.Calculator");
        dc.setCapability("autoGrantPermissions", "false");
        dc.setCapability("enforceAppInstall", "false");
        dc.setCapability("skipUnlock", "true");
        dc.setCapability("unlockType", "pin");



        //Establecemos la conexion con el server de Appium
        driver = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), dc);
        System.out.println("Application started");
    }

    @Test ()
    public void test() {
    }


    @AfterTest
    public void afterTest() {
    }

}
