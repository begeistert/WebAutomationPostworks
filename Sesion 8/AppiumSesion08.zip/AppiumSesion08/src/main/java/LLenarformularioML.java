import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LLenarformularioML {

    protected WebDriver driver;
    // Método que recibirá el driver en esta clase
    public LLenarformularioML(WebDriver driver) {
        this.driver = driver;
    }

    // Definimos objetos de tipo locator y le asignamos la localización By.
    private By bnt_continuar = By.xpath("//button[contains(.,'Continuar')]");
    private By btn_crear_cuenta = By.xpath("//button[contains(.,'Crea tu cuenta')]");
    private By name = By.id("firstName");
    private By lastname = By.id("lastName");
    private By email = By.id("email");
    private By clave = By.id("password");

    private By user = By.name("user_id");
    private By password = By.name("password");

    // Método que realizara un click en bnt_agendar
    public void ContinuarRegistro() {
        driver.findElement(btn_crear_cuenta).click();
    }

    // Método que realizara recibira un localizador e ingresara un texto
    public void fillText(By locator, String text) {
        driver.findElement(locator).clear();
        driver.findElement(locator).sendKeys(text);
    }

     // Métodos que realizara recibiran un texto a llenar en cada campo
    public void fillName(String text) {
        driver.findElement(name).clear();
        driver.findElement(name).sendKeys(text);
    }

    // Métodos que realizara recibiran un texto a llenar en cada campo
    public void filluserid(String text) {
        driver.findElement(user).clear();
        driver.findElement(user).sendKeys(text);
    }

    // Métodos que realizara recibiran un texto a llenar en cada campo
    public void filluserpassword(String text) {
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(text);
    }

    public void fillLastname(String text) {
        driver.findElement(lastname).clear();
        driver.findElement(lastname).sendKeys(text);
    }

    public void fillEmail(String text) {
        driver.findElement(email).clear();
        driver.findElement(email).sendKeys(text);
    }

    public void fillClave(String text) {
        driver.findElement(clave).clear();
        driver.findElement(clave).sendKeys(text);
    }

}
