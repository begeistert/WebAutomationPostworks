import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;

public class MercadoLibrePage {

    protected AndroidDriver driver;

    public MercadoLibrePage(AndroidDriver driver){
        this.driver = driver;
    }

    // Creamos el método que realizara click en la suma
    public void clickSuma() throws InterruptedException {
        driver.findElement(By.id("com.google.android.calculator:id/op_add")).click();
    }

    // Creamos el método que creara el localizador by para los numeros de la calculadora
    public By locateDigit(int digito){
        String locator = "com.google.android.calculator:id/digit_"+ digito;
        By digit = By.id(locator);
        return digit;

    }

    public void clickClear() throws InterruptedException {
        driver.findElement(By.id("com.google.android.calculator:id/clr")).click();
    }

    // Creamos el método que obtiene el resultado
    public String getResult() throws InterruptedException {
        Thread.sleep(2000);
        String result = driver.findElement(By.id("com.google.android.calculator:id/result_preview")).getText();
        System.out.println("El resultado es = " + result);
        return result;
    }
}
