import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;
import static java.time.Duration.ofMillis;


public class MobileTest {

    AndroidDriver driver;
    CalculatorPage calculatorPage;
    @BeforeTest
    public void beforeTest() throws MalformedURLException {
        //Configuramos los DesiredCapabilities
        DesiredCapabilities dc = new DesiredCapabilities();
        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "emulator-5554");
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        dc.setCapability("appium:appPackage", "com.google.android.youtube");
        dc.setCapability("appium:appActivity", "com.google.android.apps.youtube.app.application.Shell_HomeActivity");

        //Establecemos la conexion con el server de Appium
        driver = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), dc);
        System.out.println("Application started");
        //
//        calculatorPage = new CalculatorPage(driver);

    }

    @Test
    public void testYT() throws InterruptedException {
        driver.findElement(By.xpath("//android.widget.RelativeLayout[@content-desc=\"noe lopez\"]")).click();
        Thread.sleep(500);
        driver.findElement(By.xpath("//android.widget.Button[@content-desc=\"Shorts\"]")).click();
        Thread.sleep(500);

        new TouchAction(driver)
                .press(PointOption.point(745, 1300))
                // a bit more reliable when we add small wait
                .waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
                .moveTo(PointOption.point(745,
                        700))
                .release().perform();
        Thread.sleep(5000);
        //asserts
    }

//    @Test(priority = 1 ,dataProvider = "dataProviderCalc", dataProviderClass = MobileDataProvider.class)
//    public void suma(int a, int b) throws InterruptedException {
//        int suma = a + b;
//        //Metodo para validar que la calculadora sume correctamente
//        calculatorPage.clickClear();
//        calculatorPage.clickDigit(a);
//        calculatorPage.clickSuma();
//        calculatorPage.clickDigit(b);
//        int result = Integer.parseInt(calculatorPage.getResult());
//
//        Assert.assertEquals(result, suma);
//
//    }

    @AfterTest
    public void afterTest() {
        driver.quit();
    }


}
