import org.testng.annotations.DataProvider;

import java.sql.ResultSet;

public class data_providerml {

    @DataProvider(name = "MySQL_dataproviderml")

    public Object[][] mySQL_Data() {

        int rowCount = 0;
        int columnCount = 0;
        String myData[][] = null;
         connection_databaseml connect = new connection_databaseml();
        ResultSet res;

        try {
            connect.Conector();

            // Ejecutar consulta (query) a la BD
            String query = "SELECT * FROM usuarios";
            res = connect.executeQuery(query);

            // Obtener nro de filas y columnas
            columnCount = connect.getColumnNumber(res);
            rowCount = connect.getRowsNumber(res);

            System.out.println("Columnas : " + columnCount);
            System.out.println("Filas : " + rowCount);

            // Inicializar la matriz
            myData = new String[rowCount][columnCount];
            res = connect.executeQuery(query);

            // Llenar la matriz con el resultado de la consulta MySQL
            for(int row=0; row<rowCount; row++)
            {
                res.next();

                for(int col=1; col<=columnCount; col++)
                    myData[row][col-1] = res.getString(col);
            }

            //Cerrar la conexión
            connect.closeConnexion();

        }

        catch (Exception e) {
            e.printStackTrace();
        }

        return myData;

    }
}
