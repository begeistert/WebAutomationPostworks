import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import static org.testng.Assert.assertEquals;

public class MercadoLibresPs08Test {
    //Inicializamos el AndroidDriver
    AndroidDriver driver;
    private HomePageMLPs08 homePageML;
    private LLenarformularioML lLenarformularioML;

    @BeforeTest
    public void beforeTest() throws MalformedURLException {

        //Configuramos los DesiredCapabilities

        DesiredCapabilities dc = new DesiredCapabilities();

        // DesiredCapabilities Generales
        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 3a API 30p");
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        dc.setCapability(MobileCapabilityType.LANGUAGE, "en");
        dc.setCapability(MobileCapabilityType.LOCALE, "US");
        dc.setCapability(MobileCapabilityType.ORIENTATION, "PORTRAIT");
        dc.setCapability(MobileCapabilityType.NO_RESET, "true");
        dc.setCapability(MobileCapabilityType.FULL_RESET, "false");
        dc.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");


        // DesiredCapabilities ANDROID
        //dc.setCapability("appium:appPackage", "com.google.android.calculator");
        //dc.setCapability("appium:appActivity", "com.android.calculator2.Calculator");
        //dc.setCapability("autoGrantPermissions", "false");
        //dc.setCapability("enforceAppInstall", "false");
        //dc.setCapability("skipUnlock", "true");
        //dc.setCapability("unlockType", "pin");



        //Establecemos la conexion con el server de Appium
        driver = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), dc);
        System.out.println("Application started");
        driver.get("https://www.mercadolibre.com.mx/");
    }

    @Test()
    public void test() {
    }

    @Test(dataProvider = "MySQL_dataproviderml", dataProviderClass = data_providerml.class)
    public void ContinuarRegistro(String name, String lastname, String email, String clave) throws InterruptedException
    {

        homePageML = new HomePageMLPs08(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePageML.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                homePageML.clickButton();
                homePageML.clickButtonIngresa();

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        lLenarformularioML = new LLenarformularioML(driver);
        lLenarformularioML.filluserid(email);
        //lLenarformularioML.fillName(name);
        //lLenarformularioML.fillLastname(lastname);
        //lLenarformularioML.fillEmail(email);
        //lLenarformularioML.fillClave(clave);

        homePageML.clickButtonContinuar();
        Thread.sleep(5000);
       lLenarformularioML.filluserpassword(lastname);
    }

    @Test
    public void verificacheckboxfull() throws InterruptedException {
        //  Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");

        WebElement search_bar = driver.findElement(By.xpath("//input[@name='as_word']"));
        search_bar.sendKeys("tennis");
        search_bar.sendKeys(Keys.RETURN);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        //driver.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/button[1]")).click();
        Thread.sleep(10000);
        //Boolean str = driver.findElement(By.id("shipping_highlighted_fulfillment")).getAttribute("checked").equals("true");
        //Assert.assertFalse(str);

    }

    @Test(priority = 8)
    public void validateCP() {
       // driver.get("https://www.mercadolibre.com.mx");
        WebElement location = driver.findElement(By.xpath("/html/body/header/div/a[3]"));
        location.click();
        Assert.assertTrue(driver.getTitle().contains("Ingresa tu código postal"));
    }


    @Test(priority = 6)
    public void testVerificaPais(){
        WebElement location = driver.findElement(By.xpath("//body[@data-country='MX']"));
        Assert.assertEquals(location.getAttribute("data-country"),"MX");
    }
    @Test(priority = 2)
    public void testVerificarUrl() {
        assertEquals(driver.getCurrentUrl(), "https://www.mercadolibre.com.mx/");
    }
    //3
    @Test(priority = 3)
    public void testVerificartitulo() {
        assertEquals(driver.getTitle(), "Mercado Libre México - Envíos Gratis en el día");
    }

    @AfterTest
    public void afterTest() {
        driver.close();
    }

}
