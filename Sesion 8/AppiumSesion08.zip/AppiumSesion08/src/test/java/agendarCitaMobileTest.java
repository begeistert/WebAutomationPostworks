import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;


public class agendarCitaMobileTest {
    AndroidDriver driver;
    private HomePage homePage;
    private agendarCitaPage agendarCitaPage;

    @BeforeMethod
    public void beforeTest() throws InterruptedException, MalformedURLException {
        //Configuramos los DesiredCapabilities
        DesiredCapabilities dc = new DesiredCapabilities();

        // DesiredCapabilities Generales
        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
        dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel 3a API 30p");
        dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "android");
        dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11");
        dc.setCapability(MobileCapabilityType.ORIENTATION, "PORTRAIT");
        dc.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
        // dc.setCapability("appPackage", "com.android.com");
        // dc.setCapability("appActivity", ".App");
        // dc.setCapability("appActivity", "org.chromium.chrome.browser.document.ChromeLauncherActivity");
        //dc.setCapability(MobileCapabilityType.BROWSER_NAME, "Firefox");
        //dc.setCapability("appPackage", "org.mozilla.firefox");
        //dc.setCapability("appActivity", ".App");
        //dc.setCapability("chromedriverExecutable", "chromedriver.exe");
        //dc.setCapability(;pabilities.setCapability(“chromedriverExecutable”, “/usr/local/bin/chromedriver”);
        //Establecemos la conexion con el server de Appium
        driver = new AndroidDriver (new URL("http://127.0.0.1:4723/wd/hub"), dc);
        System.out.println("Application started");
        driver.get("https://bedu.org/");
    }


    @Test(dataProvider = "MySQL_dataprovider", dataProviderClass = data_providerbedu.class)
    public void agendarAsesoria(String name, String lastname, String phone, String email, String company,
                                String jobtitle, String sector, String company_size, String program) throws InterruptedException {

        homePage = new HomePage(driver);
        // Validamos que el boton de agendar asesoria este disponible
        if (homePage.isButtonDisplayed()) {
            // Clck en boton de agendar asesoria
            try {
                //Thread.sleep(2000);
                homePage.clickButton();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        agendarCitaPage = new agendarCitaPage(driver);

        if (agendarCitaPage.btn_CancelIsDispayed()) {

            agendarCitaPage.fillName(name);
            agendarCitaPage.fillLastname(lastname);
            agendarCitaPage.fillPhone(phone);
             agendarCitaPage.fillCompany(company);
            agendarCitaPage.fillJobTitle(jobtitle);
            agendarCitaPage.fillSector(sector);
            agendarCitaPage.fillCompanySize(company_size);
            agendarCitaPage.fillProgram(program);
            Thread.sleep(2000);
        }

    }

    @AfterMethod
    public void afterTest() {
        driver.close();
    }
}
